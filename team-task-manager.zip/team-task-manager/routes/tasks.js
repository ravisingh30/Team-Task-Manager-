const router = require("express").Router();
const db = require("../database");
const {
  authenticate,
  requireProjectMember,
  requireProjectAdmin,
} = require("../middleware/auth");

// ─── GET /api/projects/:projectId/tasks ───────────────────────────────────────
router.get("/:projectId/tasks", authenticate, requireProjectMember, (req, res) => {
  const { status, priority, assignee, search } = req.query;
  let sql = `
    SELECT t.*,
      u.name as assignee_name, u.avatar_color as assignee_color,
      c.name as created_by_name
    FROM tasks t
    LEFT JOIN users u ON t.assignee_id = u.id
    LEFT JOIN users c ON t.created_by = c.id
    WHERE t.project_id = ?
  `;
  const params = [req.params.projectId];

  if (status) { sql += " AND t.status = ?"; params.push(status); }
  if (priority) { sql += " AND t.priority = ?"; params.push(priority); }
  if (assignee) { sql += " AND t.assignee_id = ?"; params.push(assignee); }
  if (search) { sql += " AND (t.title LIKE ? OR t.description LIKE ?)"; params.push(`%${search}%`, `%${search}%`); }

  sql += " ORDER BY CASE t.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, t.created_at DESC";

  const tasks = db.prepare(sql).all(...params);
  res.json({ tasks });
});

// ─── POST /api/projects/:projectId/tasks ──────────────────────────────────────
router.post("/:projectId/tasks", authenticate, requireProjectMember, (req, res) => {
  const { title, description, priority, assignee_id, due_date } = req.body;

  if (!title?.trim()) return res.status(400).json({ error: "Task title is required" });

  // Validate assignee is a project member
  if (assignee_id) {
    const isMember = db
      .prepare("SELECT 1 FROM project_members WHERE project_id = ? AND user_id = ?")
      .get(req.params.projectId, assignee_id);
    const isOwner = db
      .prepare("SELECT 1 FROM projects WHERE id = ? AND owner_id = ?")
      .get(req.params.projectId, assignee_id);
    if (!isMember && !isOwner)
      return res.status(400).json({ error: "Assignee must be a project member" });
  }

  const result = db
    .prepare(
      `INSERT INTO tasks (project_id, title, description, priority, assignee_id, due_date, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      req.params.projectId,
      title.trim(),
      description?.trim() || "",
      priority || "medium",
      assignee_id || null,
      due_date || null,
      req.user.id
    );

  const task = db
    .prepare(
      `SELECT t.*, u.name as assignee_name, u.avatar_color as assignee_color, c.name as created_by_name
       FROM tasks t
       LEFT JOIN users u ON t.assignee_id = u.id
       LEFT JOIN users c ON t.created_by = c.id
       WHERE t.id = ?`
    )
    .get(result.lastInsertRowid);

  res.status(201).json({ task });
});

// ─── PUT /api/tasks/:id ───────────────────────────────────────────────────────
router.put("/:id", authenticate, (req, res) => {
  const task = db.prepare("SELECT * FROM tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found" });

  // Check membership
  const member = db
    .prepare("SELECT 1 FROM project_members WHERE project_id = ? AND user_id = ?")
    .get(task.project_id, req.user.id);
  const project = db.prepare("SELECT owner_id FROM projects WHERE id = ?").get(task.project_id);
  const hasAccess =
    req.user.role === "admin" ||
    project.owner_id === req.user.id ||
    member;

  if (!hasAccess) return res.status(403).json({ error: "Access denied" });

  const { title, description, status, priority, assignee_id, due_date } = req.body;

  if (!title?.trim()) return res.status(400).json({ error: "Task title is required" });

  db.prepare(
    `UPDATE tasks SET
      title = ?, description = ?, status = ?, priority = ?,
      assignee_id = ?, due_date = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(
    title.trim(),
    description?.trim() || task.description,
    status || task.status,
    priority || task.priority,
    assignee_id !== undefined ? (assignee_id || null) : task.assignee_id,
    due_date !== undefined ? (due_date || null) : task.due_date,
    req.params.id
  );

  const updated = db
    .prepare(
      `SELECT t.*, u.name as assignee_name, u.avatar_color as assignee_color, c.name as created_by_name
       FROM tasks t
       LEFT JOIN users u ON t.assignee_id = u.id
       LEFT JOIN users c ON t.created_by = c.id
       WHERE t.id = ?`
    )
    .get(req.params.id);

  res.json({ task: updated });
});

// ─── PATCH /api/tasks/:id/status  (quick status update) ──────────────────────
router.patch("/:id/status", authenticate, (req, res) => {
  const task = db.prepare("SELECT * FROM tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found" });

  const { status } = req.body;
  const validStatuses = ["todo", "in_progress", "review", "done"];
  if (!validStatuses.includes(status))
    return res.status(400).json({ error: "Invalid status" });

  db.prepare("UPDATE tasks SET status = ?, updated_at = datetime('now') WHERE id = ?").run(
    status,
    req.params.id
  );

  res.json({ success: true, status });
});

// ─── DELETE /api/tasks/:id ────────────────────────────────────────────────────
router.delete("/:id", authenticate, (req, res) => {
  const task = db.prepare("SELECT * FROM tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found" });

  const project = db.prepare("SELECT owner_id FROM projects WHERE id = ?").get(task.project_id);
  const membership = db
    .prepare("SELECT role FROM project_members WHERE project_id = ? AND user_id = ?")
    .get(task.project_id, req.user.id);

  const canDelete =
    req.user.role === "admin" ||
    project.owner_id === req.user.id ||
    task.created_by === req.user.id ||
    membership?.role === "admin";

  if (!canDelete) return res.status(403).json({ error: "Only task creator or admin can delete" });

  db.prepare("DELETE FROM tasks WHERE id = ?").run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
