const router = require("express").Router();
const bcrypt = require("bcryptjs");
const db = require("../database");
const { authenticate, signToken } = require("../middleware/auth");

const AVATAR_COLORS = [
  "#6366f1","#ec4899","#f59e0b","#10b981","#3b82f6","#8b5cf6","#ef4444","#14b8a6"
];

// ─── POST /api/auth/signup ────────────────────────────────────────────────────
router.post("/signup", (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name?.trim()) return res.status(400).json({ error: "Name is required" });
  if (!email?.trim()) return res.status(400).json({ error: "Email is required" });
  if (!password || password.length < 6)
    return res.status(400).json({ error: "Password must be at least 6 characters" });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email))
    return res.status(400).json({ error: "Invalid email format" });

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase());
  if (existing) return res.status(409).json({ error: "Email already registered" });

  const hash = bcrypt.hashSync(password, 10);
  const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  // First user becomes admin
  const count = db.prepare("SELECT COUNT(*) as c FROM users").get().c;
  const userRole = count === 0 ? "admin" : (role === "admin" ? "admin" : "member");

  const result = db
    .prepare(
      "INSERT INTO users (name, email, password, role, avatar_color) VALUES (?, ?, ?, ?, ?)"
    )
    .run(name.trim(), email.toLowerCase(), hash, userRole, color);

  const user = db
    .prepare("SELECT id, name, email, role, avatar_color, created_at FROM users WHERE id = ?")
    .get(result.lastInsertRowid);

  return res.status(201).json({ token: signToken(user), user });
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
router.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ error: "Email and password are required" });

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase());
  if (!user) return res.status(401).json({ error: "Invalid credentials" });

  const valid = bcrypt.compareSync(password, user.password);
  if (!valid) return res.status(401).json({ error: "Invalid credentials" });

  const { password: _, ...safeUser } = user;
  return res.json({ token: signToken(safeUser), user: safeUser });
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
router.get("/me", authenticate, (req, res) => {
  res.json({ user: req.user });
});

// ─── GET /api/auth/users  (admin: list all users) ────────────────────────────
router.get("/users", authenticate, (req, res) => {
  const users = db
    .prepare("SELECT id, name, email, role, avatar_color, created_at FROM users ORDER BY name")
    .all();
  res.json({ users });
});

// ─── PATCH /api/auth/users/:id/role  (admin only) ────────────────────────────
router.patch("/users/:id/role", authenticate, (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ error: "Admin access required" });

  const { role } = req.body;
  if (!["admin", "member"].includes(role))
    return res.status(400).json({ error: "Role must be admin or member" });

  db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, req.params.id);
  res.json({ success: true });
});

module.exports = router;
