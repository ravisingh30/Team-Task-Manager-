const router = require("express").Router();
const db = require("../database");
const { authenticate } = require("../middleware/auth");

// ─── GET /api/dashboard ───────────────────────────────────────────────────────
router.get("/", authenticate, (req, res) => {
  const uid = req.user.id;
  const isAdmin = req.user.role === "admin";

  // Projects the user is part of
  const projectFilter = isAdmin
    ? ""
    : `AND (p.owner_id = ${uid} OR EXISTS (SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = ${uid}))`;

  // ── Task stats across all accessible projects ────────────────────────────
  const taskStats = db
    .prepare(
      `SELECT
        COUNT(*) as total,
        SUM(CASE WHEN t.status = 'todo' THEN 1 ELSE 0 END) as todo,
        SUM(CASE WHEN t.status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN t.status = 'review' THEN 1 ELSE 0 END) as review,
        SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) as done,
        SUM(CASE WHEN t.due_date < date('now') AND t.status != 'done' THEN 1 ELSE 0 END) as overdue
       FROM tasks t
       JOIN projects p ON t.project_id = p.id
       WHERE 1=1 ${projectFilter}`
    )
    .get();

  // ── Tasks assigned to ME ─────────────────────────────────────────────────
  const myTasks = db
    .prepare(
      `SELECT t.*, p.name as project_name, u.name as assignee_name, u.avatar_color as assignee_color
       FROM tasks t
       JOIN projects p ON t.project_id = p.id
       LEFT JOIN users u ON t.assignee_id = u.id
       WHERE t.assignee_id = ? AND t.status != 'done'
       ORDER BY CASE WHEN t.due_date IS NOT NULL AND t.due_date < date('now') THEN 0 ELSE 1 END,
                t.due_date ASC NULLS LAST,
                CASE t.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END
       LIMIT 10`
    )
    .all(uid);

  // ── Overdue tasks ────────────────────────────────────────────────────────
  const overdueTasks = db
    .prepare(
      `SELECT t.*, p.name as project_name, u.name as assignee_name, u.avatar_color as assignee_color
       FROM tasks t
       JOIN projects p ON t.project_id = p.id
       LEFT JOIN users u ON t.assignee_id = u.id
       WHERE t.due_date < date('now') AND t.status != 'done'
         ${projectFilter.replace("p.", "p.")}
       ORDER BY t.due_date ASC
       LIMIT 8`
    )
    .all();

  // ── Recent activity (last 10 updated tasks) ──────────────────────────────
  const recentActivity = db
    .prepare(
      `SELECT t.*, p.name as project_name, u.name as assignee_name, u.avatar_color as assignee_color
       FROM tasks t
       JOIN projects p ON t.project_id = p.id
       LEFT JOIN users u ON t.assignee_id = u.id
       WHERE 1=1 ${projectFilter}
       ORDER BY t.updated_at DESC
       LIMIT 8`
    )
    .all();

  // ── Project summary ──────────────────────────────────────────────────────
  const projects = db
    .prepare(
      `SELECT p.id, p.name, p.status,
         COUNT(t.id) as task_count,
         SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) as done_count,
         SUM(CASE WHEN t.due_date < date('now') AND t.status != 'done' THEN 1 ELSE 0 END) as overdue_count
       FROM projects p
       LEFT JOIN tasks t ON t.project_id = p.id
       WHERE 1=1 ${projectFilter}
       GROUP BY p.id
       ORDER BY p.created_at DESC
       LIMIT 6`
    )
    .all();

  // ── Team size (admin only) ───────────────────────────────────────────────
  const teamSize = isAdmin
    ? db.prepare("SELECT COUNT(*) as c FROM users").get().c
    : null;

  res.json({
    taskStats,
    myTasks,
    overdueTasks,
    recentActivity,
    projects,
    teamSize,
  });
});

module.exports = router;
