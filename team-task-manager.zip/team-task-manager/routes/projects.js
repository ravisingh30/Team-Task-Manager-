const router = require("express").Router();
const db = require("../database");
const {
  authenticate,
  requireProjectMember,
  requireProjectAdmin,
} = require("../middleware/auth");

// ─── GET /api/projects  ───────────────────────────────────────────────────────
router.get("/", authenticate, (req, res) => {
  let projects;
  if (req.user.role === "admin") {
    projects = db
      .prepare(
        `SELECT p.*, u.name as owner_name,
          (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) as task_count,
          (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'done') as done_count,
          (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id = p.id) as member_count
         FROM projects p JOIN users u ON p.owner_id = u.id
         ORDER BY p.created_at DESC`
      )
      .all();
  } else {
    projects = db
      .prepare(
        `SELECT p.*, u.name as owner_name,
          (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) as task_count,
          (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'done') as done_count,
          (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id = p.id) as member_count
         FROM projects p
         JOIN users u ON p.owner_id = u.id
         WHERE p.owner_id = ? OR EXISTS (
           SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = ?
         )
         ORDER BY p.created_at DESC`
      )
      .all(req.user.id, req.user.id);
  }
  res.json({ projects });
});

// ─── POST /api/projects ───────────────────────────────────────────────────────
router.post("/", authenticate, (req, res) => {
  const { name, description } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: "Project name is required" });

  const result = db
    .prepare("INSERT INTO projects (name, description, owner_id) VALUES (?, ?, ?)")
    .run(name.trim(), description?.trim() || "", req.user.id);

  // Owner is also an admin member
  db.prepare("INSERT OR IGNORE INTO project_members (project_id, user_id, role) VALUES (?, ?, 'admin')")
    .run(result.lastInsertRowid, req.user.id);

  const project = db
    .prepare("SELECT p.*, u.name as owner_name FROM projects p JOIN users u ON p.owner_id = u.id WHERE p.id = ?")
    .get(result.lastInsertRowid);

  res.status(201).json({ project });
});

// ─── GET /api/projects/:id ────────────────────────────────────────────────────
router.get("/:id", authenticate, requireProjectMember, (req, res) => {
  const members = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.avatar_color, u.role as global_role, pm.role as project_role, pm.joined_at
       FROM project_members pm JOIN users u ON pm.user_id = u.id
       WHERE pm.project_id = ?`
    )
    .all(req.params.id);

  const stats = db
    .prepare(
      `SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'todo' THEN 1 ELSE 0 END) as todo,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN status = 'review' THEN 1 ELSE 0 END) as review,
        SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as done,
        SUM(CASE WHEN due_date < date('now') AND status != 'done' THEN 1 ELSE 0 END) as overdue
       FROM tasks WHERE project_id = ?`
    )
    .get(req.params.id);

  res.json({ project: req.project, members, stats, projectRole: req.projectRole });
});

// ─── PUT /api/projects/:id ────────────────────────────────────────────────────
router.put("/:id", authenticate, requireProjectAdmin, (req, res) => {
  const { name, description, status } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: "Project name is required" });

  db.prepare("UPDATE projects SET name = ?, description = ?, status = ? WHERE id = ?").run(
    name.trim(),
    description?.trim() || "",
    status || "active",
    req.params.id
  );

  const project = db.prepare("SELECT * FROM projects WHERE id = ?").get(req.params.id);
  res.json({ project });
});

// ─── DELETE /api/projects/:id ─────────────────────────────────────────────────
router.delete("/:id", authenticate, requireProjectAdmin, (req, res) => {
  db.prepare("DELETE FROM projects WHERE id = ?").run(req.params.id);
  res.json({ success: true });
});

// ─── GET /api/projects/:projectId/members ─────────────────────────────────────
router.get("/:projectId/members", authenticate, requireProjectMember, (req, res) => {
  const members = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.avatar_color, pm.role as project_role, pm.joined_at
       FROM project_members pm JOIN users u ON pm.user_id = u.id
       WHERE pm.project_id = ? ORDER BY pm.joined_at ASC`
    )
    .all(req.params.projectId);
  res.json({ members });
});

// ─── POST /api/projects/:projectId/members ────────────────────────────────────
router.post("/:projectId/members", authenticate, requireProjectAdmin, (req, res) => {
  const { userId, role } = req.body;
  if (!userId) return res.status(400).json({ error: "userId is required" });

  const user = db.prepare("SELECT id FROM users WHERE id = ?").get(userId);
  if (!user) return res.status(404).json({ error: "User not found" });

  db.prepare(
    "INSERT OR REPLACE INTO project_members (project_id, user_id, role) VALUES (?, ?, ?)"
  ).run(req.params.projectId, userId, role || "member");

  res.status(201).json({ success: true });
});

// ─── DELETE /api/projects/:projectId/members/:userId ─────────────────────────
router.delete("/:projectId/members/:userId", authenticate, requireProjectAdmin, (req, res) => {
  // Can't remove the owner
  const project = db.prepare("SELECT owner_id FROM projects WHERE id = ?").get(req.params.projectId);
  if (parseInt(req.params.userId) === project.owner_id)
    return res.status(400).json({ error: "Cannot remove project owner" });

  // Unassign their tasks in this project
  db.prepare(
    "UPDATE tasks SET assignee_id = NULL WHERE project_id = ? AND assignee_id = ?"
  ).run(req.params.projectId, req.params.userId);

  db.prepare("DELETE FROM project_members WHERE project_id = ? AND user_id = ?").run(
    req.params.projectId,
    req.params.userId
  );
  res.json({ success: true });
});

module.exports = router;
