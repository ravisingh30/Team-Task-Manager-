const jwt = require("jsonwebtoken");
const db = require("../database");

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_change_in_production";

// ─── Verify JWT token ─────────────────────────────────────────────────────────
function authenticate(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) return res.status(401).json({ error: "No token provided" });

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db
      .prepare("SELECT id, name, email, role, avatar_color, created_at FROM users WHERE id = ?")
      .get(payload.id);
    if (!user) return res.status(401).json({ error: "User not found" });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

// ─── Require global Admin role ────────────────────────────────────────────────
function requireAdmin(req, res, next) {
  if (req.user.role !== "admin")
    return res.status(403).json({ error: "Admin access required" });
  next();
}

// ─── Require project membership (any role) ───────────────────────────────────
function requireProjectMember(req, res, next) {
  const projectId = parseInt(req.params.projectId || req.params.id);
  const project = db.prepare("SELECT * FROM projects WHERE id = ?").get(projectId);

  if (!project) return res.status(404).json({ error: "Project not found" });

  // Global admins and project owners always have access
  if (req.user.role === "admin" || project.owner_id === req.user.id) {
    req.project = project;
    req.projectRole = "admin";
    return next();
  }

  const membership = db
    .prepare("SELECT * FROM project_members WHERE project_id = ? AND user_id = ?")
    .get(projectId, req.user.id);

  if (!membership)
    return res.status(403).json({ error: "You are not a member of this project" });

  req.project = project;
  req.projectRole = membership.role;
  next();
}

// ─── Require project admin role ───────────────────────────────────────────────
function requireProjectAdmin(req, res, next) {
  requireProjectMember(req, res, () => {
    if (req.projectRole !== "admin" && req.user.role !== "admin")
      return res.status(403).json({ error: "Project admin access required" });
    next();
  });
}

function signToken(user) {
  return jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "7d" });
}

module.exports = {
  authenticate,
  requireAdmin,
  requireProjectMember,
  requireProjectAdmin,
  signToken,
};
